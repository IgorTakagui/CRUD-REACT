import { useEffect, useState } from 'react';
import { getLivros, deleteLivros } from '../services/api';
import { Link } from 'react-router-dom';
interface Livro {
 id: string;
 nome: string;
 autor: string;
 valor: number;
 quantidade: number;
}
function LivroList() {
 const [Livros, setLivros] = useState<Livro[]>([]);
 useEffect(() => {
 loadLivros();
 }, []);
 const loadLivros = async () => {
 const response = await getLivros();
 setLivros(response.data);
 };
 const handleDelete = async (id: string) => {
 await deleteLivros(id);
 loadLivros();
 };
 return (
 <div>
 <h1>Livro List</h1>
 <Link to="/add">Add Livro</Link>
 <ul>
 {Livros.map((Livro) => (
 <li key={Livro.id}>
 {Livro.nome} - ${Livro.valor} - {Livro.quantidade} units
 <Link to={`/edit/${Livro.id}`}>Edit</Link>
 <button onClick={() => handleDelete(Livro.id)}>Delete</button>
 </li>
 ))}
 </ul>
 </div>
 );
}
export default LivroList;