import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createLivro, getLivrosById, updateLivros } from '../services/api';
interface Livro {
 nome: string;
 Autor: string;
 valor: number;
 Quantidade: number;
}
function LivroForm() {
 const { id } = useParams<{ id: string }>();
 const navigate = useNavigate();
 const [Livro, setLivro] = useState<Livro>({
 nome: '',
 Autor: '',
 valor: 0,
 Quantidade: 0,
 });
 useEffect(() => {
 if (id) {
 loadLivro();
 }
 }, [id]);
 const loadLivro = async () => {
 try {
 const response = await getLivrosById(id as string);
 setLivro(response.data);
 } catch (error) {
 console.error("Error loading Livro data", error);
 }
 };
 const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
 setLivro({
 ...Livro,
 [e.target.name]: e.target.value,
 });
 };
 const handleSubmit = async (e: React.FormEvent) => {
 e.preventDefault();
 try {
 if (id) {
 await updateLivros(id, Livro);
 } else {
 await createLivro(Livro);
 }
 navigate('/');
 } catch (error) {
 console.error("Error saving Livro", error);
 }
 };
 return (
 <form onSubmit={handleSubmit}>
 <div>
 <label>nome</label>
 <input
 type="text"
 name="nome"
 value={Livro.nome}
 onChange={handleChange}
 />
 </div>
 <div>
 <label>Autor</label>
 <input
 type="text"
 name="Autor"
 value={Livro.Autor}
 onChange={handleChange}
 />
 </div>
 <div>
 <label>valor</label>
 <input
 type="number"
 name="valor"
 value={Livro.valor}
 onChange={handleChange}
 />
 </div>
 <div>
 <label>Quantidade</label>
 <input
 type="number"
 name="Quantidade"
 value={Livro.Quantidade}
 onChange={handleChange}
 />
 </div>
 <button type="submit">Save</button>
 </form>
 );
}
export default LivroForm;