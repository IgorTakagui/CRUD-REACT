import axios from 'axios';
const api = axios.create({
 baseURL: 'http://localhost:3001'
});
export const getLivros = () => api.get('/Livros');
export const getLivrosById = (id: string) => api.get(`/Livros/${id}`);
export const createLivro = (Livro: any) => api.post('/Livros', Livro);
export const updateLivros = (id: string, Livro: any) => api.put(`/Livros/${id}`, Livro);
export const deleteLivros = (id: string) => api.delete(`/Livros/${id}`);